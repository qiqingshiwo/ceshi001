package io.sofastack.cloud.common.constants;

/**
 * @author: guolei.sgl (guolei.sgl@antfin.com) 2019/3/5 2:05 PM
 * @since:
 **/
public class KafkaConstants {
    public static final String TRADE_TOPIC = "trading";
}
